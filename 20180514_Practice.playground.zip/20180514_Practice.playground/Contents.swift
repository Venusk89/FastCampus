//: Playground - noun: a place where people can play

import UIKit

func nameOutput(name: String) -> Void {
    print(name)
}
nameOutput(name: "김효성")

func ageOutput(age: Int) -> Void {
    print(age)
}
ageOutput(age: 20)

print("=====================================")

func introduceMySelf(name: String, age: Int) {
    print("제 이름은 \(name)입니다. 제 나이는 \(age)입니다.")
}
introduceMySelf(name: "김효성", age: 20)

print("=====================================")

func aMultipleOfTwo(number: Int) -> String {
    if number % 2 == 0 {
        return "2의 배수입니다"
    } else {
        return "2의 배수가 아닙니다"
    }
}

aMultipleOfTwo(number: 5)
print(aMultipleOfTwo(number: 4))

print("=====================================")

func multipleTwoNumbers(number: Int = 10, number2: Int) -> Int {
    return number * number2
}

multipleTwoNumbers(number2: 5)
print(multipleTwoNumbers(number2: 6))

print("=====================================")

func averageFourClass(math: Int, english: Int, history: Int, music: Int) -> Int {
    var total: Int
    total = math + english + history + music
    return total / 4
}

averageFourClass(math: 50, english: 60, history: 70, music: 80)
